
# 🎰 Jackpot Buffalo 🐃

✨ A Game by Boss Baby – Powered by ChatGPT  
“AI နဲ့ Developer အတူတူဖြစ်တဲ့ ပထမဆုံးစမ်းသပ်မှု”

Jackpot Buffalo is an African-themed mobile slot game created through a human–AI collaboration between Boss Baby (developer) and ChatGPT (AI assistant). It demonstrates the power of AI-assisted rapid development and showcases modern UI, Firebase integration, and interactive gameplay features.

## 🌟 Features
- 7 Unique Themed Rooms (Buffalo Classic, Lion Rush, etc.)
- Realtime Coin Sync via Firebase
- Chatroom Integration
- Spin Engine with Line Matching
- Leaderboard & Daily Bonus System

## 📂 Repository Structure
- **README.md**: Project overview and credits.
- **source/**: Android Studio project source code.
- **apk/**: Debug APK (to be added).
- **screenshots/**: UI screenshots.

## 🚀 How to Use
1. Place your Android Studio project files inside the `source/` folder.
2. Place the Debug APK inside the `apk/` folder.
3. Add UI screenshots to the `screenshots/` folder.
4. Configure `google-services.json` in your project under `app/`.

---
✨ A Game by Boss Baby – Powered by ChatGPT  
“AI နဲ့ Developer အတူတူဖြစ်တဲ့ ပထမဆုံးစမ်းသပ်မှု”
